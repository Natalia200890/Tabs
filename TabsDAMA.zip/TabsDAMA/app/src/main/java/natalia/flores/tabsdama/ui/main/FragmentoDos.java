package natalia.flores.tabsdama.ui.main;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.telephony.PhoneNumberUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import natalia.flores.tabsdama.R;


public class FragmentoDos extends Fragment {
    View vista1;
    Button enviar1;

    private String url;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        vista1=inflater.inflate(R.layout.fragment_fragmento_dos, container, false);

        enviar1= (Button) vista1.findViewById(R.id.btnenviar1);
        enviar1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.univo.edu.sv"));
                startActivity(browserIntent);
            }
        });
        return vista1;

    }

}