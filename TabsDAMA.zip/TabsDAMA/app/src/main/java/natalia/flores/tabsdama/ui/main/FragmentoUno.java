package natalia.flores.tabsdama.ui.main;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.telephony.PhoneNumberUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import natalia.flores.tabsdama.R;

public class FragmentoUno extends Fragment {
    View vista;
     Button enviar;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        vista=inflater.inflate(R.layout.fragment_fragmento_uno, container, false);
        enviar= (Button) vista.findViewById(R.id.btnenviar);

        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String numeroTelefono = "50374702412";
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.setPackage("com.whatsapp");
                sendIntent.setType("text/plain");
                sendIntent.putExtra("jid", PhoneNumberUtils.stripSeparators(numeroTelefono) + "@s.whatsapp.net");
                sendIntent.putExtra(Intent.EXTRA_TEXT, "Prueba de mensaje");
                startActivity(sendIntent);
            }
        });
                return vista;

    }

}